namespace Application;

public class Figura261E06
{
    public static double Perimetro(double a, double b)
    {
        return Math.PI * (a + b);
    }
    public static double Area(double a, double b)
    {
        return Math.PI * a * b;
    }
    public static double Volumen(double Area, double altura)
    {
        return Area * altura;
    }
}
