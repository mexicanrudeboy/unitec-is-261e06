﻿double a = 5;
double b = 10;
double altura = 20;
double perimetro = Application.Figura261E06.Perimetro(a, b);
double area = Application.Figura261E06.Area(a, b);
double volumen = Application.Figura261E06.Volumen(area, altura);

Console.WriteLine($"el perimetro de una elipse con eje mayor {b} y eje menor {a} es: {perimetro}cm");
Console.WriteLine($"el area de una elipse con eje mayor {b} y eje menor {a} es: {area}cm2");
Console.WriteLine($"el volumen de un prisma elíptico con ejes {a}, {b} y altura {altura} es: {volumen}cm3");
